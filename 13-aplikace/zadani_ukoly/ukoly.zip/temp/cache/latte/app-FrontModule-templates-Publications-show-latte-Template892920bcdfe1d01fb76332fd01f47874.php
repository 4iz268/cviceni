<?php
// source: E:\Pracovn�\V�E\fulltext-repository\app\FrontModule/templates/Publications/show.latte

class Template892920bcdfe1d01fb76332fd01f47874 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('7f91cb529e', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lba44da97d23_content')) { function _lba44da97d23_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>

  <h2>Základní informace</h2>
  <table class="listTable">
    <tr>
      <th scope="row" style="width:20%;">Jazyk publikace</th>
      <td>CZE</td>
    </tr>
    <tr>
      <th scope="row">Název CZ</th>
      <td><?php echo Latte\Runtime\Filters::escapeHtml($publication->title, ENT_NOQUOTES) ?></td>
    </tr>
    <tr>
      <th scope="row">Název EN</th>
      <td>Development of entrepreneurial attitudes and entrepreneurial activity of youths in the Czech Republic.</td>
    </tr>
    <tr>
      <th scope="row">Autoři</th>
      <td>Lukeš, Martin; Zouhar, Jan</td>
    </tr>
    <tr>
      <th scope="row">Klíčová slova</th>
      <td>podnikatelská aktivita, podnikatelské přesvědčení</td>
    </tr>
    <tr>
      <th scope="row">Sborník</th>
      <td>The 8th International Days of Statistics and Economics Conference Proceedings</td>
    </tr>
  </table>

  <div class="actions">
    <a class="btn btn-primary">potvrdit správnost</a>
    <a class="btn btn-default">opravit záznam</a>
  </div>

  <h2>Text publikace</h2>
  <table class="listTable">
    <tr>
      <th scope="row" style="width:20%;">Preprint verze</th>
      <td><span class="error">nenahráno</span></td>
    </tr>
    <tr>
      <th scope="row">Postprint verze</th>
      <td><span class="error">nenahráno</span></td>
    </tr>
    <tr>
      <th scope="row">Vydavatelská verze:</th>
      <td><span class="error">nenahráno</span></td>
    </tr>
  </table>

  <form style="margin:40px 10px;">
    <table>
      <tr>
        <td><label>Typ textu:</label></td>
        <td>
          <select>
            <option>--vyberte--</option>
            <option>preprint</option>
            <option>postprint</option>
            <option>vydavatelská verze</option>
          </select>
        </td>
      </tr>
      <tr>
        <td><label>Soubor:</label></td>
        <td><input type="file"></td>
      </tr>
      <tr>
        <td><label>Viditelný soubor:</label></td>
        <td>
          <select>
            <option>--vyberte--</option>
            <option>ano</option>
            <option>ne</option>
          </select>
        </td>
      </tr>
    </table>
    <div class="actions" style="padding: 20px;">
      <input type="submit" value="nahrát soubor..." class="btn btn-primary">
    </div>
  </form>

  <h2>Licence, zveřejnění publikace</h2>
  <table class="listTable">
    <tr>
      <th scope="row" style="width: 20%;"><abbr title="Datum, po kterém dojde ke zveřejnění textu publikace">Publikační embargo</abbr></th>
      <td>nenastaveno - zobrazit ihned</td>
    </tr>
    <tr>
      <th>Licence:</th>
      <td>--nezadáno-- <a href="" class="btn-sm btn-primary">změnit</a></td>
    </tr>
    <tr>
      <th>Soubor s licencí:</th>
      <td><a href="" class="btn-sm btn-primary">nahrát</a></td>
    </tr>
    <tr>
      <th>Alternativní URL:</th>
      <td><a href="" class="btn-sm btn-primary">přidat URL</a></td>
    </tr>
  </table>

  <h2>Datové soubory, přílohy</h2>
  <p><em>Data, která byla využita pro zpracování aplikace či přílohy publikace</em></p>

  
<?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb41ecbaaa57_title')) { function _lb41ecbaaa57_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>  <h1><?php echo Latte\Runtime\Filters::escapeHtml($publication->title, ENT_NOQUOTES) ?></h1>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start(function () {});}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIRuntime::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ?>
      <?php
}}