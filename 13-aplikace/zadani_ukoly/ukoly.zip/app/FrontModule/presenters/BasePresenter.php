<?php

namespace Ukoly\FrontModule\Presenters;

use Ukoly\Model\Entities\Author;
use Ukoly\Model\Translation\IUkolyTranslator;
use Nette\Application\UI\Presenter;

/**
 * Class BasePresenter
 * @package Ukoly\FrontModule\Presenters
 * @author Stanislav Vojíř
 */
class BasePresenter extends Presenter{
  /** @var  IUkolyTranslator $translator */
  protected $translator;

  public function beforeRender(){
    $this->template->setTranslator($this->translator);
  }

  
  public function injectTranslator(IUkolyTranslator $translator){
    $this->translator=$translator;
  }

}