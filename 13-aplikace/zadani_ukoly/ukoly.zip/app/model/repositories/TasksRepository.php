<?php

namespace Ukoly\Model\Repositories;


class TasksRepository extends BaseRepository{

}