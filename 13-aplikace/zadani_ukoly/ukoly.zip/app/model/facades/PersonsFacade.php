<?php

namespace Ukoly\Model\Facades;


use Ukoly\Model\Entities\Person;
use Ukoly\Model\Entities\Task;
use Ukoly\Model\Repositories\PersonsRepository;
use Ukoly\Model\Repositories\TasksRepository;

class PersonsFacade{

  /** @var  PersonsRepository $personsRepository */
  private $personsRepository;
  /** @var  TasksRepository $tasksRepository */
  private $tasksRepository;

  public function __construct(PersonsRepository $personsRepository, TasksRepository $tasksRepository){
    $this->personsRepository=$personsRepository;
    $this->tasksRepository=$tasksRepository;
  }

  /**
   * @return Person[]
   */
  public function findPersons(){
    return $this->personsRepository->findAll();
  }

  /**
   * @return Task[]
   */
  public function findTasks(){
    return $this->tasksRepository->findAll();
  }

  /**
   * @param int $id
   * @return Person
   */
  public function findPerson($id){
    return $this->personsRepository->find($id);
  }

  /**
   * @param Person $person
   */
  public function savePerson(Person $person){
    $this->personsRepository->persist($person);
  }

  /**
   * @param Person|int $person
   */
  public function deletePerson($person){
    if (!($person instanceof Person)){
      $person=$this->findPerson($person);
    }
    $this->personsRepository->delete($person);
  }

  /**
   * @param int $id
   * @return Task
   */
  public function findTask($id){
    return $this->tasksRepository->find($id);
  }

  /**
   * @param Task $task
   */
  public function saveTask(Task $task){
    $this->tasksRepository->persist($task);
  }

  /**
   * @param Task|int $task
   */
  public function deleteTask($task){
    if (!($task instanceof Task)){
      $task=$this->findTask($task);
    }
    $this->tasksRepository->delete($task);
  }

}