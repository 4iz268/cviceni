<?php
namespace Ukoly\Model\Translation;


use Nette\Localization\ITranslator;

/**
 * Interface UkolyTranslator
 * @package Ukoly\Model\Translation
 * @author Stanislav Vojíř
 */
interface IUkolyTranslator extends ITranslator{

  /**
   * Funkce vracející aktuálně nastavený jazyk
   * @return string
   */
  public function getLang();

}