<?php

namespace Ukoly\Model\Entities;


use LeanMapper\Entity;

/**
 * Class Person
 * @package Ukoly\Model\Entities
 * @property int|null $personId=null
 * @property string $name
 * @property string $email
 * @property string $street
 * @property string $city
 * @property string $zip
 * @property string $phone
 * @property-read Task[] $tasks m:belongsToMany
 */
class Person extends Entity{


  public function getDataArr($onlyBasicInfo=false){
    $result=[
      'id'=>$this->personId,
      'name'=>$this->name,
      'email'=>$this->email
    ];
    if (!$onlyBasicInfo){
      $result['street']=@$this->street;
      $result['city']=@$this->city;
      $result['zip']=@$this->zip;
      $result['phone']=@$this->phone;
    }
    return $result;
  }
}