<?php

namespace Ukoly\Model\Exceptions;
use LeanMapper\Exception\Exception;

class EntityNotFoundException extends Exception{

}