<?php

namespace Ukoly\Model\Parsers;
use Ukoly\Model\Exceptions\InvalidArgumentException;

/**
 * Class AlephXml- třída pro zpracování XML dat exportovaných z Alephu
 * @package Ukoly\Model\Parsers
 * @author Stanislav Vojíř
 */
class AlephXml{
  /** @var  \SimpleXMLElement $xml */
  private $xml;

  /**
   * AlephXml constructor.
   * @param string|\SimpleXMLElement $xml
   * @throws InvalidArgumentException
   */
  public function __construct($xml){
    if (is_string($xml)){
      $this->xml=simplexml_load_string($xml);
    }elseif($xml instanceof \SimpleXMLElement){
      $this->xml=$xml;
    }else{
      throw new InvalidArgumentException();
    }
  }

  /**
   * Funkce vracející jeden konkrétní záznam z XML na základě jeho sysno
   * @param string $sysno
   * @return AlephRecordXml
   * @throws InvalidArgumentException
   */
  public function getRecord($sysno){
    if (count($this->xml->record)>0){
      foreach($this->xml->record as $recordXml){
        if (count($recordXml->controlfield)>0){
          foreach($recordXml->controlfield as $controlfieldXml){
            if ($controlfieldXml['tag']=='001' && (string)$controlfieldXml==$sysno){
              return new AlephRecordXml($recordXml);
            }
          }
        }
      }
    }
    throw new InvalidArgumentException();
  }

  /**
   * Funkce vracející připravené XML záznamy v objektech třídy AlephRecordXml
   * @return AlephRecordXml[]
   */
  public function getRecords(){
    $result=[];
    if (count(@$this->xml->record)>0){
      foreach($this->xml->record as $recordXml){
        $result[]=new AlephRecordXml($recordXml);
      }
    }
    return $result;
  }
  
  
}