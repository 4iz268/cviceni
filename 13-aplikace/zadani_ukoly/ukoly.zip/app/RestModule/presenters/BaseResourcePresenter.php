<?php
namespace Ukoly\RestModule\Presenters;

use Drahak\Restful\Resource\Link;
use Drahak\Restful\Application\UI\ResourcePresenter;
use Drahak\Restful\Http\IInput;
use Drahak\Restful\Validation\IDataProvider;
use Ukoly\RestModule\Model\Mappers\XmlMapper;
use Nette\Application\Responses\TextResponse;
use Nette\Security\AuthenticationException;
use Nette\Security\IAuthenticator;

/**
 * Class BaseResourcePresenter
 * @package Ukoly\RestModule\Presenters
 * @property IInput|IDataProvider $input
 *
 * @SWG\Swagger(
 *   basePath="%BASE_PATH%",
 *   host="%HOST%",
 *   schemes={"http"},
 *   @SWG\Info(
 *     title="Ukoly REST API",
 *     version="0.1",
 *     description="",
 *     @SWG\Contact(name="Stanislav Vojíř",email="stanislav.vojir@vse.cz"),
 *     @SWG\License(name="BSD3",url="http://opensource.org/licenses/BSD-3-Clause")
 *   )
 * )
 *
 * @SWG\Tag(
 *   name="Persons",
 *   description="Acces to persons"
 * )
 * @SWG\Tag(
 *   name="Tasks",
 *   description="Access to tasks"
 * )
 */
abstract class BaseResourcePresenter extends ResourcePresenter {
  /** @var \Ukoly\RestModule\Model\Mappers\XmlMapper $xmlMapper */
  protected $xmlMapper=null;

  /**
   * Funkce pro odeslání XML odpovědi
   * @param \SimpleXMLElement|string $simpleXml
   */
  protected function sendXmlResponse($simpleXml){
    $httpResponse=$this->getHttpResponse();
    $httpResponse->setContentType('application/xml','UTF-8');
    $this->sendResponse(new TextResponse(($simpleXml instanceof \SimpleXMLElement?$simpleXml->asXML():$simpleXml)));
  }

  /**
   * Funkce pro odeslání textové odpovědi
   * @param string $text
   */
  protected function sendTextResponse($text) {
    $httpResponse=$this->getHttpResponse();
    $httpResponse->setContentType('text/plain','UTF-8');
    $this->sendResponse(new TextResponse($text));
  }

  /**
   * Funkce pro odeslání HTML odpovědi
   * @param string $text
   */
  protected function sendHtmlResponse($text) {
    $httpResponse=$this->getHttpResponse();
    $httpResponse->setContentType('text/html','UTF-8');
    $this->sendResponse(new TextResponse($text));
  }

  /**
   * Funkce pro nastavení specifikace XML elementů
   * @param string $rootElement
   * @param string $itemElement
   */
  protected function setXmlMapperElements($rootElement, $itemElement="") {
    $this->xmlMapper->setRootElement($rootElement);
    //TODO set namespace
    if (!empty($itemElement)){
      $this->xmlMapper->setItemElement($itemElement);
    }
  }

  /**
   * Funkce vracející absolutní URL zadaného linku
   * @param string $destination
   * @param array $args
   * @param string $rel
   * @param bool $includeCurrentParams=false - pokud je true, dojde ke sloučení aktuálních parametrů a parametrů nových
   * @return string
   */
  protected function getAbsoluteLink($destination, $args=[], $rel=Link::SELF, $includeCurrentParams=false) {
    if (($destination=='self'||$destination=='//self')&&empty($args)){
      $args=$this->params;
    }elseif($includeCurrentParams){
      $args=array_merge($this->params,$args);
    }
    $link=$this->link($destination, $args, $rel)->getHref();
    if ($link[0]=='/'){
      return $this->getHttpRequest()->getUrl()->getHostUrl().$link;
    }else{
      return $link;
    }
  }


  public function injectXmlMapper(XmlMapper $xmlMapper){
    $this->xmlMapper=$xmlMapper;
  }

}

/**
 * @SWG\Definition(
 *   definition="StatusResponse",
 *   title="Status",
 *   required={"code","status"},
 *   @SWG\Property(property="code", type="integer", description="Status code"),
 *   @SWG\Property(property="status", type="string", description="Status string", enum={"OK","error"}),
 *   @SWG\Property(property="message", type="string", description="User-friendly message")
 * )
 * @SWG\Definition(
 *   definition="InputErrorResponse",
 *   title="InputError",
 *   required={"code","status"},
 *   @SWG\Property(property="code", type="integer", description="Status code"),
 *   @SWG\Property(property="status", type="string", description="Status string", enum={"OK","error"}),
 *   @SWG\Property(property="message", type="string", description="User-friendly message"),
 *   @SWG\Property(
 *     property="errors",
 *     type="array",
 *     description="List of errors",
 *     @SWG\Items(
 *       ref="#/definitions/InputErrorItem"
 *     )
 *   )
 * )
 * @SWG\Definition(
 *   definition="InputErrorItem",
 *   title="InputErrorItem",
 *   @SWG\Property(property="field", type="string"),
 *   @SWG\Property(property="message", type="string"),
 *   @SWG\Property(property="code", type="integer")
 * )
 *
 */