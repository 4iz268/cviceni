<?php
// source: E:\Pracovn�\V�E DEV\ukoly\app/config/config.neon 
// source: E:\Pracovn�\V�E DEV\ukoly\app/config/config.local.neon 

class Container_725ec0de55 extends Nette\DI\Container
{
	protected $meta = array(
		'types' => array(
			'Nette\Object' => array(
				array(
					'application.application',
					'application.linkGenerator',
					'http.requestFactory',
					'http.request',
					'http.response',
					'http.context',
					'nette.template',
					'security.user',
					'session.session',
					'restful.responseFactory',
					'restful.resourceFactory',
					'restful.methodOptions',
					'restful.xmlMapper',
					'restful.jsonMapper',
					'restful.queryMapper',
					'restful.dataUrlMapper',
					'restful.nullMapper',
					'restful.mapperContext',
					'restful.inputFactory',
					'restful.httpResponseFactory',
					'restful.requestFilter',
					'restful.methodHandler',
					'restful.validator',
					'restful.validationScopeFactory',
					'restful.validationScope',
					'restful.objectConverter',
					'restful.dateTimeConverter',
					'restful.camelCaseConverter',
					'restful.pascalCaseConverter',
					'restful.snakeCaseConverter',
					'restful.resourceConverter',
					'restful.security.hashCalculator',
					'restful.security.hashAuthenticator',
					'restful.security.timeoutAuthenticator',
					'restful.security.nullAuthentication',
					'restful.security.securedAuthentication',
					'restful.security.basicAuthentication',
					'restful.security.authentication',
					'60_Ukoly_RestModule_Model_Mappers_XmlMapper',
					'application.1',
					'application.2',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
					'container',
				),
			),
			'Nette\Application\Application' => array(1 => array('application.application')),
			'Nette\Application\IPresenterFactory' => array(
				1 => array('application.presenterFactory'),
			),
			'Nette\Application\LinkGenerator' => array(1 => array('application.linkGenerator')),
			'Nette\Caching\Storages\IJournal' => array(1 => array('cache.journal')),
			'Nette\Caching\IStorage' => array(1 => array('cache.storage')),
			'Nette\Http\RequestFactory' => array(1 => array('http.requestFactory')),
			'Nette\Http\IRequest' => array(1 => array('http.request')),
			'Nette\Http\Request' => array(1 => array('http.request')),
			'Nette\Http\IResponse' => array(1 => array('http.response')),
			'Nette\Http\Response' => array(1 => array('http.response')),
			'Nette\Http\Context' => array(1 => array('http.context')),
			'Nette\Bridges\ApplicationLatte\ILatteFactory' => array(1 => array('latte.latteFactory')),
			'Nette\Application\UI\ITemplateFactory' => array(1 => array('latte.templateFactory')),
			'Latte\Object' => array(array('nette.latte')),
			'Latte\Engine' => array(array('nette.latte')),
			'Nette\Templating\Template' => array(array('nette.template')),
			'Nette\Templating\ITemplate' => array(array('nette.template')),
			'Nette\Templating\IFileTemplate' => array(array('nette.template')),
			'Nette\Templating\FileTemplate' => array(array('nette.template')),
			'Nette\Mail\IMailer' => array(1 => array('mail.mailer')),
			'Nette\Application\IRouter' => array(1 => array('routing.router')),
			'Nette\Security\IUserStorage' => array(1 => array('security.userStorage')),
			'Nette\Security\User' => array(1 => array('security.user')),
			'Nette\Http\Session' => array(1 => array('session.session')),
			'Tracy\ILogger' => array(1 => array('tracy.logger')),
			'Tracy\BlueScreen' => array(1 => array('tracy.blueScreen')),
			'Tracy\Bar' => array(1 => array('tracy.bar')),
			'Drahak\Restful\Application\IResponseFactory' => array(1 => array('restful.responseFactory')),
			'Drahak\Restful\Application\ResponseFactory' => array(1 => array('restful.responseFactory')),
			'Drahak\Restful\IResourceFactory' => array(1 => array('restful.resourceFactory')),
			'Drahak\Restful\ResourceFactory' => array(1 => array('restful.resourceFactory')),
			'Drahak\Restful\IResource' => array(1 => array('restful.resource')),
			'Drahak\Restful\Application\MethodOptions' => array(1 => array('restful.methodOptions')),
			'Drahak\Restful\Mapping\IMapper' => array(
				1 => array(
					'restful.xmlMapper',
					'restful.jsonMapper',
					'restful.queryMapper',
					'restful.dataUrlMapper',
					'restful.nullMapper',
					'60_Ukoly_RestModule_Model_Mappers_XmlMapper',
				),
			),
			'Drahak\Restful\Mapping\XmlMapper' => array(
				1 => array(
					'restful.xmlMapper',
					'60_Ukoly_RestModule_Model_Mappers_XmlMapper',
				),
			),
			'Drahak\Restful\Mapping\JsonMapper' => array(1 => array('restful.jsonMapper')),
			'Drahak\Restful\Mapping\QueryMapper' => array(1 => array('restful.queryMapper')),
			'Drahak\Restful\Mapping\DataUrlMapper' => array(1 => array('restful.dataUrlMapper')),
			'Drahak\Restful\Mapping\NullMapper' => array(1 => array('restful.nullMapper')),
			'Drahak\Restful\Mapping\MapperContext' => array(1 => array('restful.mapperContext')),
			'Drahak\Restful\Http\InputFactory' => array(1 => array('restful.inputFactory')),
			'Drahak\Restful\Http\ResponseFactory' => array(
				1 => array('restful.httpResponseFactory'),
			),
			'Drahak\Restful\Http\ApiRequestFactory' => array(
				1 => array('restful.httpRequestFactory'),
			),
			'Drahak\Restful\Utils\RequestFilter' => array(1 => array('restful.requestFilter')),
			'Drahak\Restful\Application\Events\MethodHandler' => array(1 => array('restful.methodHandler')),
			'Drahak\Restful\Validation\IValidator' => array(1 => array('restful.validator')),
			'Drahak\Restful\Validation\Validator' => array(1 => array('restful.validator')),
			'Drahak\Restful\Validation\IValidationScopeFactory' => array(
				1 => array('restful.validationScopeFactory'),
			),
			'Drahak\Restful\Validation\ValidationScopeFactory' => array(
				1 => array('restful.validationScopeFactory'),
			),
			'Drahak\Restful\Validation\IValidationScope' => array(1 => array('restful.validationScope')),
			'Drahak\Restful\Validation\ValidationScope' => array(1 => array('restful.validationScope')),
			'Drahak\Restful\Converters\IConverter' => array(
				1 => array(
					'restful.objectConverter',
					'restful.dateTimeConverter',
					'restful.camelCaseConverter',
					'restful.pascalCaseConverter',
					'restful.snakeCaseConverter',
				),
			),
			'Drahak\Restful\Converters\ObjectConverter' => array(1 => array('restful.objectConverter')),
			'Drahak\Restful\Converters\DateTimeConverter' => array(1 => array('restful.dateTimeConverter')),
			'Drahak\Restful\Converters\CamelCaseConverter' => array(
				1 => array('restful.camelCaseConverter'),
			),
			'Drahak\Restful\Converters\PascalCaseConverter' => array(
				1 => array('restful.pascalCaseConverter'),
			),
			'Drahak\Restful\Converters\SnakeCaseConverter' => array(
				1 => array('restful.snakeCaseConverter'),
			),
			'Drahak\Restful\Converters\ResourceConverter' => array(1 => array('restful.resourceConverter')),
			'Drahak\Restful\Security\IAuthTokenCalculator' => array(
				1 => array('restful.security.hashCalculator'),
			),
			'Drahak\Restful\Security\HashCalculator' => array(
				1 => array('restful.security.hashCalculator'),
			),
			'Drahak\Restful\Security\Authentication\IRequestAuthenticator' => array(
				1 => array(
					'restful.security.hashAuthenticator',
					'restful.security.timeoutAuthenticator',
				),
			),
			'Drahak\Restful\Security\Authentication\HashAuthenticator' => array(
				1 => array('restful.security.hashAuthenticator'),
			),
			'Drahak\Restful\Security\Authentication\TimeoutAuthenticator' => array(
				1 => array('restful.security.timeoutAuthenticator'),
			),
			'Drahak\Restful\Security\Process\AuthenticationProcess' => array(
				1 => array(
					'restful.security.nullAuthentication',
					'restful.security.securedAuthentication',
					'restful.security.basicAuthentication',
				),
			),
			'Drahak\Restful\Security\Process\NullAuthentication' => array(
				1 => array('restful.security.nullAuthentication'),
			),
			'Drahak\Restful\Security\Process\SecuredAuthentication' => array(
				1 => array(
					'restful.security.securedAuthentication',
				),
			),
			'Drahak\Restful\Security\Process\BasicAuthentication' => array(
				1 => array('restful.security.basicAuthentication'),
			),
			'Drahak\Restful\Security\AuthenticationContext' => array(
				1 => array('restful.security.authentication'),
			),
			'Joseki\Application\ErrorPresenterFactory' => array(1 => array('ErrorPresenter.factory')),
			'LeanMapper\IEntityFactory' => array(
				1 => array('54_LeanMapper_DefaultEntityFactory'),
			),
			'LeanMapper\DefaultEntityFactory' => array(
				1 => array('54_LeanMapper_DefaultEntityFactory'),
			),
			'Ukoly\Model\Facades\PersonsFacade' => array(
				1 => array('55_Ukoly_Model_Facades_PersonsFacade'),
			),
			'LeanMapper\DefaultMapper' => array(
				1 => array('56_Ukoly_Model_Mappers_StandardMapper'),
			),
			'LeanMapper\IMapper' => array(
				1 => array('56_Ukoly_Model_Mappers_StandardMapper'),
			),
			'Ukoly\Model\Mappers\StandardMapper' => array(
				1 => array('56_Ukoly_Model_Mappers_StandardMapper'),
			),
			'Ukoly\Model\Repositories\BaseRepository' => array(
				1 => array(
					'57_Ukoly_Model_Repositories_PersonsRepository',
					'58_Ukoly_Model_Repositories_TasksRepository',
				),
			),
			'LeanMapper\Repository' => array(
				1 => array(
					'57_Ukoly_Model_Repositories_PersonsRepository',
					'58_Ukoly_Model_Repositories_TasksRepository',
				),
			),
			'Ukoly\Model\Repositories\PersonsRepository' => array(
				1 => array(
					'57_Ukoly_Model_Repositories_PersonsRepository',
				),
			),
			'Ukoly\Model\Repositories\TasksRepository' => array(
				1 => array(
					'58_Ukoly_Model_Repositories_TasksRepository',
				),
			),
			'Ukoly\Model\Translation\IUkolyTranslator' => array(1 => array('translator')),
			'Nette\Localization\ITranslator' => array(1 => array('translator')),
			'Ukoly\Model\Translation\BlankTranslator' => array(1 => array('translator')),
			'Ukoly\RestModule\Model\Mappers\XmlMapper' => array(
				1 => array(
					'60_Ukoly_RestModule_Model_Mappers_XmlMapper',
				),
			),
			'Dibi\Connection' => array(1 => array('61_LeanMapper_Connection')),
			'LeanMapper\Connection' => array(1 => array('61_LeanMapper_Connection')),
			'Nette\Application\UI\Presenter' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\Application\UI\Control' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\Application\UI\PresenterComponent' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\ComponentModel\Container' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\ComponentModel\Component' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\Application\IPresenter' => array(
				array(
					'application.1',
					'application.2',
					'application.3',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
					'application.9',
					'application.10',
				),
			),
			'ArrayAccess' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\Application\UI\IStatePersistent' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\Application\UI\ISignalReceiver' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\ComponentModel\IComponent' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\ComponentModel\IContainer' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Nette\Application\UI\IRenderable' => array(
				array(
					'application.1',
					'application.2',
					'application.4',
					'application.5',
					'application.6',
					'application.7',
					'application.8',
				),
			),
			'Ukoly\FrontModule\Presenters\BasePresenter' => array(array('application.1', 'application.4')),
			'Ukoly\FrontModule\Presenters\Error4xxPresenter' => array(array('application.2')),
			'Ukoly\FrontModule\Presenters\ErrorPresenter' => array(array('application.3')),
			'Ukoly\FrontModule\Presenters\HomepagePresenter' => array(array('application.4')),
			'Ukoly\RestModule\Presenters\DefaultPresenter' => array(array('application.5')),
			'Ukoly\RestModule\Presenters\BaseResourcePresenter' => array(array('application.6', 'application.8')),
			'Drahak\Restful\Application\UI\ResourcePresenter' => array(array('application.6', 'application.8')),
			'Drahak\Restful\Application\IResourcePresenter' => array(array('application.6', 'application.8')),
			'Ukoly\RestModule\Presenters\PersonsPresenter' => array(array('application.6')),
			'Ukoly\RestModule\Presenters\SwaggerPresenter' => array(array('application.7')),
			'Ukoly\RestModule\Presenters\TasksPresenter' => array(array('application.8')),
			'NetteModule\ErrorPresenter' => array(array('application.9')),
			'NetteModule\MicroPresenter' => array(array('application.10')),
			'Nette\DI\Container' => array(1 => array('container')),
		),
		'services' => array(
			'54_LeanMapper_DefaultEntityFactory' => 'LeanMapper\DefaultEntityFactory',
			'55_Ukoly_Model_Facades_PersonsFacade' => 'Ukoly\Model\Facades\PersonsFacade',
			'56_Ukoly_Model_Mappers_StandardMapper' => 'Ukoly\Model\Mappers\StandardMapper',
			'57_Ukoly_Model_Repositories_PersonsRepository' => 'Ukoly\Model\Repositories\PersonsRepository',
			'58_Ukoly_Model_Repositories_TasksRepository' => 'Ukoly\Model\Repositories\TasksRepository',
			'60_Ukoly_RestModule_Model_Mappers_XmlMapper' => 'Ukoly\RestModule\Model\Mappers\XmlMapper',
			'61_LeanMapper_Connection' => 'LeanMapper\Connection',
			'ErrorPresenter.factory' => 'Joseki\Application\ErrorPresenterFactory',
			'application.1' => 'Ukoly\FrontModule\Presenters\BasePresenter',
			'application.10' => 'NetteModule\MicroPresenter',
			'application.2' => 'Ukoly\FrontModule\Presenters\Error4xxPresenter',
			'application.3' => 'Ukoly\FrontModule\Presenters\ErrorPresenter',
			'application.4' => 'Ukoly\FrontModule\Presenters\HomepagePresenter',
			'application.5' => 'Ukoly\RestModule\Presenters\DefaultPresenter',
			'application.6' => 'Ukoly\RestModule\Presenters\PersonsPresenter',
			'application.7' => 'Ukoly\RestModule\Presenters\SwaggerPresenter',
			'application.8' => 'Ukoly\RestModule\Presenters\TasksPresenter',
			'application.9' => 'NetteModule\ErrorPresenter',
			'application.application' => 'Nette\Application\Application',
			'application.linkGenerator' => 'Nette\Application\LinkGenerator',
			'application.presenterFactory' => 'Nette\Application\IPresenterFactory',
			'cache.journal' => 'Nette\Caching\Storages\IJournal',
			'cache.storage' => 'Nette\Caching\IStorage',
			'container' => 'Nette\DI\Container',
			'http.context' => 'Nette\Http\Context',
			'http.request' => 'Nette\Http\Request',
			'http.requestFactory' => 'Nette\Http\RequestFactory',
			'http.response' => 'Nette\Http\Response',
			'latte.latteFactory' => 'Latte\Engine',
			'latte.templateFactory' => 'Nette\Application\UI\ITemplateFactory',
			'mail.mailer' => 'Nette\Mail\IMailer',
			'nette.latte' => 'Latte\Engine',
			'nette.template' => 'Nette\Templating\FileTemplate',
			'restful.camelCaseConverter' => 'Drahak\Restful\Converters\CamelCaseConverter',
			'restful.dataUrlMapper' => 'Drahak\Restful\Mapping\DataUrlMapper',
			'restful.dateTimeConverter' => 'Drahak\Restful\Converters\DateTimeConverter',
			'restful.httpRequestFactory' => 'Drahak\Restful\Http\ApiRequestFactory',
			'restful.httpResponseFactory' => 'Drahak\Restful\Http\ResponseFactory',
			'restful.inputFactory' => 'Drahak\Restful\Http\InputFactory',
			'restful.jsonMapper' => 'Drahak\Restful\Mapping\JsonMapper',
			'restful.mapperContext' => 'Drahak\Restful\Mapping\MapperContext',
			'restful.methodHandler' => 'Drahak\Restful\Application\Events\MethodHandler',
			'restful.methodOptions' => 'Drahak\Restful\Application\MethodOptions',
			'restful.nullMapper' => 'Drahak\Restful\Mapping\NullMapper',
			'restful.objectConverter' => 'Drahak\Restful\Converters\ObjectConverter',
			'restful.pascalCaseConverter' => 'Drahak\Restful\Converters\PascalCaseConverter',
			'restful.queryMapper' => 'Drahak\Restful\Mapping\QueryMapper',
			'restful.requestFilter' => 'Drahak\Restful\Utils\RequestFilter',
			'restful.resource' => 'Drahak\Restful\IResource',
			'restful.resourceConverter' => 'Drahak\Restful\Converters\ResourceConverter',
			'restful.resourceFactory' => 'Drahak\Restful\ResourceFactory',
			'restful.responseFactory' => 'Drahak\Restful\Application\ResponseFactory',
			'restful.security.authentication' => 'Drahak\Restful\Security\AuthenticationContext',
			'restful.security.basicAuthentication' => 'Drahak\Restful\Security\Process\BasicAuthentication',
			'restful.security.hashAuthenticator' => 'Drahak\Restful\Security\Authentication\HashAuthenticator',
			'restful.security.hashCalculator' => 'Drahak\Restful\Security\HashCalculator',
			'restful.security.nullAuthentication' => 'Drahak\Restful\Security\Process\NullAuthentication',
			'restful.security.securedAuthentication' => 'Drahak\Restful\Security\Process\SecuredAuthentication',
			'restful.security.timeoutAuthenticator' => 'Drahak\Restful\Security\Authentication\TimeoutAuthenticator',
			'restful.snakeCaseConverter' => 'Drahak\Restful\Converters\SnakeCaseConverter',
			'restful.validationScope' => 'Drahak\Restful\Validation\ValidationScope',
			'restful.validationScopeFactory' => 'Drahak\Restful\Validation\ValidationScopeFactory',
			'restful.validator' => 'Drahak\Restful\Validation\Validator',
			'restful.xmlMapper' => 'Drahak\Restful\Mapping\XmlMapper',
			'routing.router' => 'Nette\Application\IRouter',
			'security.user' => 'Nette\Security\User',
			'security.userStorage' => 'Nette\Security\IUserStorage',
			'session.session' => 'Nette\Http\Session',
			'tracy.bar' => 'Tracy\Bar',
			'tracy.blueScreen' => 'Tracy\BlueScreen',
			'tracy.logger' => 'Tracy\ILogger',
			'translator' => 'Ukoly\Model\Translation\BlankTranslator',
		),
		'tags' => array(
			'inject' => array(
				'application.1' => TRUE,
				'application.10' => TRUE,
				'application.2' => TRUE,
				'application.3' => TRUE,
				'application.4' => TRUE,
				'application.5' => TRUE,
				'application.6' => TRUE,
				'application.7' => TRUE,
				'application.8' => TRUE,
				'application.9' => TRUE,
			),
			'nette.presenter' => array(
				'application.1' => 'Ukoly\FrontModule\Presenters\BasePresenter',
				'application.10' => 'NetteModule\MicroPresenter',
				'application.2' => 'Ukoly\FrontModule\Presenters\Error4xxPresenter',
				'application.3' => 'Ukoly\FrontModule\Presenters\ErrorPresenter',
				'application.4' => 'Ukoly\FrontModule\Presenters\HomepagePresenter',
				'application.5' => 'Ukoly\RestModule\Presenters\DefaultPresenter',
				'application.6' => 'Ukoly\RestModule\Presenters\PersonsPresenter',
				'application.7' => 'Ukoly\RestModule\Presenters\SwaggerPresenter',
				'application.8' => 'Ukoly\RestModule\Presenters\TasksPresenter',
				'application.9' => 'NetteModule\ErrorPresenter',
			),
			'restful.converter' => array(
				'restful.camelCaseConverter' => TRUE,
				'restful.dateTimeConverter' => TRUE,
				'restful.objectConverter' => TRUE,
			),
		),
		'aliases' => array(
			'application' => 'application.application',
			'cacheStorage' => 'cache.storage',
			'httpRequest' => 'http.request',
			'httpResponse' => 'http.response',
			'nette.cacheJournal' => 'cache.journal',
			'nette.httpContext' => 'http.context',
			'nette.httpRequestFactory' => 'http.requestFactory',
			'nette.latteFactory' => 'latte.latteFactory',
			'nette.mailer' => 'mail.mailer',
			'nette.presenterFactory' => 'application.presenterFactory',
			'nette.templateFactory' => 'latte.templateFactory',
			'nette.userStorage' => 'security.userStorage',
			'router' => 'routing.router',
			'session' => 'session.session',
			'user' => 'security.user',
		),
	);


	public function __construct()
	{
		parent::__construct(array(
			'appDir' => "E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app",
			'wwwDir' => "E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\www",
			'debugMode' => TRUE,
			'productionMode' => FALSE,
			'environment' => 'development',
			'consoleMode' => FALSE,
			'container' => array('class' => NULL, 'parent' => NULL),
			'tempDir' => "E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app/../temp",
			'database' => array(
				'driver' => 'mysqli',
				'host' => 'localhost',
				'username' => 'root',
				'password' => NULL,
				'database' => 'ukoly',
				'encoding' => 'utf8',
			),
		));
	}


	/**
	 * @return LeanMapper\DefaultEntityFactory
	 */
	public function createService__54_LeanMapper_DefaultEntityFactory()
	{
		$service = new LeanMapper\DefaultEntityFactory;
		return $service;
	}


	/**
	 * @return Ukoly\Model\Facades\PersonsFacade
	 */
	public function createService__55_Ukoly_Model_Facades_PersonsFacade()
	{
		$service = new Ukoly\Model\Facades\PersonsFacade($this->getService('57_Ukoly_Model_Repositories_PersonsRepository'),
			$this->getService('58_Ukoly_Model_Repositories_TasksRepository'));
		return $service;
	}


	/**
	 * @return Ukoly\Model\Mappers\StandardMapper
	 */
	public function createService__56_Ukoly_Model_Mappers_StandardMapper()
	{
		$service = new Ukoly\Model\Mappers\StandardMapper;
		return $service;
	}


	/**
	 * @return Ukoly\Model\Repositories\PersonsRepository
	 */
	public function createService__57_Ukoly_Model_Repositories_PersonsRepository()
	{
		$service = new Ukoly\Model\Repositories\PersonsRepository($this->getService('61_LeanMapper_Connection'), $this->getService('56_Ukoly_Model_Mappers_StandardMapper'),
			$this->getService('54_LeanMapper_DefaultEntityFactory'));
		return $service;
	}


	/**
	 * @return Ukoly\Model\Repositories\TasksRepository
	 */
	public function createService__58_Ukoly_Model_Repositories_TasksRepository()
	{
		$service = new Ukoly\Model\Repositories\TasksRepository($this->getService('61_LeanMapper_Connection'), $this->getService('56_Ukoly_Model_Mappers_StandardMapper'),
			$this->getService('54_LeanMapper_DefaultEntityFactory'));
		return $service;
	}


	/**
	 * @return Ukoly\RestModule\Model\Mappers\XmlMapper
	 */
	public function createService__60_Ukoly_RestModule_Model_Mappers_XmlMapper()
	{
		$service = new Ukoly\RestModule\Model\Mappers\XmlMapper;
		return $service;
	}


	/**
	 * @return LeanMapper\Connection
	 */
	public function createService__61_LeanMapper_Connection()
	{
		$service = new LeanMapper\Connection(array(
			'driver' => 'mysqli',
			'host' => 'localhost',
			'username' => 'root',
			'password' => NULL,
			'database' => 'ukoly',
			'encoding' => 'utf8',
		));
		return $service;
	}


	/**
	 * @return Joseki\Application\ErrorPresenterFactory
	 */
	public function createService__ErrorPresenter__factory()
	{
		$service = new Joseki\Application\ErrorPresenterFactory($this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'));
		return $service;
	}


	/**
	 * @return Ukoly\FrontModule\Presenters\BasePresenter
	 */
	public function createServiceApplication__1()
	{
		$service = new Ukoly\FrontModule\Presenters\BasePresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->injectTranslator($this->getService('translator'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return NetteModule\MicroPresenter
	 */
	public function createServiceApplication__10()
	{
		$service = new NetteModule\MicroPresenter($this, $this->getService('http.request'), $this->getService('routing.router'));
		return $service;
	}


	/**
	 * @return Ukoly\FrontModule\Presenters\Error4xxPresenter
	 */
	public function createServiceApplication__2()
	{
		$service = new Ukoly\FrontModule\Presenters\Error4xxPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return Ukoly\FrontModule\Presenters\ErrorPresenter
	 */
	public function createServiceApplication__3()
	{
		$service = new Ukoly\FrontModule\Presenters\ErrorPresenter($this->getService('tracy.logger'));
		return $service;
	}


	/**
	 * @return Ukoly\FrontModule\Presenters\HomepagePresenter
	 */
	public function createServiceApplication__4()
	{
		$service = new Ukoly\FrontModule\Presenters\HomepagePresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->injectTranslator($this->getService('translator'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return Ukoly\RestModule\Presenters\DefaultPresenter
	 */
	public function createServiceApplication__5()
	{
		$service = new Ukoly\RestModule\Presenters\DefaultPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return Ukoly\RestModule\Presenters\PersonsPresenter
	 */
	public function createServiceApplication__6()
	{
		$service = new Ukoly\RestModule\Presenters\PersonsPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->injectDrahakRestful($this->getService('restful.responseFactory'), $this->getService('restful.resourceFactory'),
			$this->getService('restful.security.authentication'), $this->getService('restful.inputFactory'), $this->getService('restful.requestFilter'));
		$service->injectXmlMapper($this->getService('60_Ukoly_RestModule_Model_Mappers_XmlMapper'));
		$service->injectPersonsFacade($this->getService('55_Ukoly_Model_Facades_PersonsFacade'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return Ukoly\RestModule\Presenters\SwaggerPresenter
	 */
	public function createServiceApplication__7()
	{
		$service = new Ukoly\RestModule\Presenters\SwaggerPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return Ukoly\RestModule\Presenters\TasksPresenter
	 */
	public function createServiceApplication__8()
	{
		$service = new Ukoly\RestModule\Presenters\TasksPresenter;
		$service->injectPrimary($this, $this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'), $this->getService('session.session'),
			$this->getService('security.user'), $this->getService('latte.templateFactory'));
		$service->injectDrahakRestful($this->getService('restful.responseFactory'), $this->getService('restful.resourceFactory'),
			$this->getService('restful.security.authentication'), $this->getService('restful.inputFactory'), $this->getService('restful.requestFilter'));
		$service->injectXmlMapper($this->getService('60_Ukoly_RestModule_Model_Mappers_XmlMapper'));
		$service->injectPersonsFacade($this->getService('55_Ukoly_Model_Facades_PersonsFacade'));
		$service->invalidLinkMode = 5;
		return $service;
	}


	/**
	 * @return NetteModule\ErrorPresenter
	 */
	public function createServiceApplication__9()
	{
		$service = new NetteModule\ErrorPresenter($this->getService('tracy.logger'));
		return $service;
	}


	/**
	 * @return Nette\Application\Application
	 */
	public function createServiceApplication__application()
	{
		$service = new Nette\Application\Application($this->getService('application.presenterFactory'), $this->getService('routing.router'),
			$this->getService('http.request'), $this->getService('http.response'));
		$service->catchExceptions = FALSE;
		$service->errorPresenter = 'Front:Error';
		Nette\Bridges\ApplicationTracy\RoutingPanel::initializePanel($service);
		$service->onStartup[] = array(
			$this->getService('restful.methodHandler'),
			'run',
		);
		$service->onError[] = array(
			$this->getService('restful.methodHandler'),
			'error',
		);
		$this->getService('tracy.bar')->addPanel(new Nette\Bridges\ApplicationTracy\RoutingPanel($this->getService('routing.router'), $this->getService('http.request'),
			$this->getService('application.presenterFactory')));
		return $service;
	}


	/**
	 * @return Nette\Application\LinkGenerator
	 */
	public function createServiceApplication__linkGenerator()
	{
		$service = new Nette\Application\LinkGenerator($this->getService('routing.router'), $this->getService('http.request')->getUrl(),
			$this->getService('application.presenterFactory'));
		return $service;
	}


	/**
	 * @return Nette\Application\IPresenterFactory
	 */
	public function createServiceApplication__presenterFactory()
	{
		$service = new Nette\Application\PresenterFactory(new Nette\Bridges\ApplicationDI\PresenterFactoryCallback($this, 5, "E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app/../temp/cache/Nette%5CBridges%5CApplicationDI%5CApplicationExtension"));
		$service->setMapping(array(
			'*' => 'Ukoly\*Module\Presenters\*Presenter',
		));
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\IJournal
	 */
	public function createServiceCache__journal()
	{
		$service = new Nette\Caching\Storages\FileJournal("E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app/../temp");
		return $service;
	}


	/**
	 * @return Nette\Caching\IStorage
	 */
	public function createServiceCache__storage()
	{
		$service = new Nette\Caching\Storages\FileStorage("E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app/../temp/cache", $this->getService('cache.journal'));
		return $service;
	}


	/**
	 * @return Nette\DI\Container
	 */
	public function createServiceContainer()
	{
		return $this;
	}


	/**
	 * @return Nette\Http\Context
	 */
	public function createServiceHttp__context()
	{
		$service = new Nette\Http\Context($this->getService('http.request'), $this->getService('http.response'));
		return $service;
	}


	/**
	 * @return Nette\Http\Request
	 */
	public function createServiceHttp__request()
	{
		$service = $this->getService('restful.httpRequestFactory')->createHttpRequest();
		if (!$service instanceof Nette\Http\Request) {
			throw new Nette\UnexpectedValueException('Unable to create service \'http.request\', value returned by factory is not Nette\Http\Request type.');
		}
		return $service;
	}


	/**
	 * @return Nette\Http\RequestFactory
	 */
	public function createServiceHttp__requestFactory()
	{
		$service = new Nette\Http\RequestFactory;
		$service->setProxy(array());
		return $service;
	}


	/**
	 * @return Nette\Http\Response
	 */
	public function createServiceHttp__response()
	{
		$service = $this->getService('restful.httpResponseFactory')->createHttpResponse();
		if (!$service instanceof Nette\Http\Response) {
			throw new Nette\UnexpectedValueException('Unable to create service \'http.response\', value returned by factory is not Nette\Http\Response type.');
		}
		return $service;
	}


	/**
	 * @return Nette\Bridges\ApplicationLatte\ILatteFactory
	 */
	public function createServiceLatte__latteFactory()
	{
		return new Container_725ec0de55_Nette_Bridges_ApplicationLatte_ILatteFactoryImpl_latte_latteFactory($this);
	}


	/**
	 * @return Nette\Application\UI\ITemplateFactory
	 */
	public function createServiceLatte__templateFactory()
	{
		$service = new Nette\Bridges\ApplicationLatte\TemplateFactory($this->getService('latte.latteFactory'), $this->getService('http.request'),
			$this->getService('http.response'), $this->getService('security.user'), $this->getService('cache.storage'));
		return $service;
	}


	/**
	 * @return Nette\Mail\IMailer
	 */
	public function createServiceMail__mailer()
	{
		$service = new Nette\Mail\SendmailMailer;
		return $service;
	}


	/**
	 * @return Latte\Engine
	 */
	public function createServiceNette__latte()
	{
		$service = new Latte\Engine;
		trigger_error('Service nette.latte is deprecated, implement Nette\Bridges\ApplicationLatte\ILatteFactory.',
			16384);
		$service->setTempDirectory("E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app/../temp/cache/latte");
		$service->setAutoRefresh(TRUE);
		$service->setContentType('html');
		Nette\Utils\Html::$xhtml = FALSE;
		return $service;
	}


	/**
	 * @return Nette\Templating\FileTemplate
	 */
	public function createServiceNette__template()
	{
		$service = new Nette\Templating\FileTemplate;
		trigger_error('Service nette.template is deprecated.', 16384);
		$service->registerFilter($this->getService('latte.latteFactory')->create());
		$service->registerHelperLoader('Nette\Templating\Helpers::loader');
		return $service;
	}


	/**
	 * @return Drahak\Restful\Converters\CamelCaseConverter
	 */
	public function createServiceRestful__camelCaseConverter()
	{
		$service = new Drahak\Restful\Converters\CamelCaseConverter;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Mapping\DataUrlMapper
	 */
	public function createServiceRestful__dataUrlMapper()
	{
		$service = new Drahak\Restful\Mapping\DataUrlMapper;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Converters\DateTimeConverter
	 */
	public function createServiceRestful__dateTimeConverter()
	{
		$service = new Drahak\Restful\Converters\DateTimeConverter('c');
		return $service;
	}


	/**
	 * @return Drahak\Restful\Http\ApiRequestFactory
	 */
	public function createServiceRestful__httpRequestFactory()
	{
		$service = new Drahak\Restful\Http\ApiRequestFactory($this->getService('http.requestFactory'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Http\ResponseFactory
	 */
	public function createServiceRestful__httpResponseFactory()
	{
		$service = new Drahak\Restful\Http\ResponseFactory($this->getService('http.request'), $this->getService('restful.requestFilter'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Http\InputFactory
	 */
	public function createServiceRestful__inputFactory()
	{
		$service = new Drahak\Restful\Http\InputFactory($this->getService('http.request'), $this->getService('restful.mapperContext'),
			$this->getService('restful.validationScopeFactory'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Mapping\JsonMapper
	 */
	public function createServiceRestful__jsonMapper()
	{
		$service = new Drahak\Restful\Mapping\JsonMapper;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Mapping\MapperContext
	 */
	public function createServiceRestful__mapperContext()
	{
		$service = new Drahak\Restful\Mapping\MapperContext;
		$service->addMapper('application/xml', $this->getService('restful.xmlMapper'));
		$service->addMapper('application/json', $this->getService('restful.jsonMapper'));
		$service->addMapper('application/javascript', $this->getService('restful.jsonMapper'));
		$service->addMapper('application/x-www-form-urlencoded', $this->getService('restful.queryMapper'));
		$service->addMapper('application/x-data-url', $this->getService('restful.dataUrlMapper'));
		$service->addMapper('application/octet-stream', $this->getService('restful.nullMapper'));
		$service->addMapper(NULL, $this->getService('restful.nullMapper'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Application\Events\MethodHandler
	 */
	public function createServiceRestful__methodHandler()
	{
		$service = new Drahak\Restful\Application\Events\MethodHandler($this->getService('http.request'), $this->getService('http.response'),
			$this->getService('restful.methodOptions'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Application\MethodOptions
	 */
	public function createServiceRestful__methodOptions()
	{
		$service = new Drahak\Restful\Application\MethodOptions($this->getService('routing.router'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Mapping\NullMapper
	 */
	public function createServiceRestful__nullMapper()
	{
		$service = new Drahak\Restful\Mapping\NullMapper;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Converters\ObjectConverter
	 */
	public function createServiceRestful__objectConverter()
	{
		$service = new Drahak\Restful\Converters\ObjectConverter;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Converters\PascalCaseConverter
	 */
	public function createServiceRestful__pascalCaseConverter()
	{
		$service = new Drahak\Restful\Converters\PascalCaseConverter;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Mapping\QueryMapper
	 */
	public function createServiceRestful__queryMapper()
	{
		$service = new Drahak\Restful\Mapping\QueryMapper;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Utils\RequestFilter
	 */
	public function createServiceRestful__requestFilter()
	{
		$service = new Drahak\Restful\Utils\RequestFilter($this->getService('http.request'), array('jsonp', 'pretty'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\IResource
	 */
	public function createServiceRestful__resource()
	{
		$service = $this->getService('restful.resourceFactory')->create();
		if (!$service instanceof Drahak\Restful\IResource) {
			throw new Nette\UnexpectedValueException('Unable to create service \'restful.resource\', value returned by factory is not Drahak\Restful\IResource type.');
		}
		return $service;
	}


	/**
	 * @return Drahak\Restful\Converters\ResourceConverter
	 */
	public function createServiceRestful__resourceConverter()
	{
		$service = new Drahak\Restful\Converters\ResourceConverter;
		$service->addConverter($this->getService('restful.objectConverter'));
		$service->addConverter($this->getService('restful.dateTimeConverter'));
		$service->addConverter($this->getService('restful.camelCaseConverter'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\ResourceFactory
	 */
	public function createServiceRestful__resourceFactory()
	{
		$service = new Drahak\Restful\ResourceFactory($this->getService('http.request'), $this->getService('restful.resourceConverter'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Application\ResponseFactory
	 */
	public function createServiceRestful__responseFactory()
	{
		$service = new Drahak\Restful\Application\ResponseFactory($this->getService('http.response'), $this->getService('http.request'),
			$this->getService('restful.mapperContext'));
		$service->setJsonp('jsonp');
		$service->setPrettyPrintKey('pretty');
		$service->setPrettyPrint(TRUE);
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\AuthenticationContext
	 */
	public function createServiceRestful__security__authentication()
	{
		$service = new Drahak\Restful\Security\AuthenticationContext;
		$service->setAuthProcess($this->getService('restful.security.nullAuthentication'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\Process\BasicAuthentication
	 */
	public function createServiceRestful__security__basicAuthentication()
	{
		$service = new Drahak\Restful\Security\Process\BasicAuthentication($this->getService('security.user'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\Authentication\HashAuthenticator
	 */
	public function createServiceRestful__security__hashAuthenticator()
	{
		$service = new Drahak\Restful\Security\Authentication\HashAuthenticator(NULL, $this->getService('http.request'), $this->getService('restful.security.hashCalculator'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\HashCalculator
	 */
	public function createServiceRestful__security__hashCalculator()
	{
		$service = new Drahak\Restful\Security\HashCalculator($this->getService('restful.mapperContext'), $this->getService('http.request'));
		$service->setPrivateKey(NULL);
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\Process\NullAuthentication
	 */
	public function createServiceRestful__security__nullAuthentication()
	{
		$service = new Drahak\Restful\Security\Process\NullAuthentication;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\Process\SecuredAuthentication
	 */
	public function createServiceRestful__security__securedAuthentication()
	{
		$service = new Drahak\Restful\Security\Process\SecuredAuthentication($this->getService('restful.security.hashAuthenticator'),
			$this->getService('restful.security.timeoutAuthenticator'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Security\Authentication\TimeoutAuthenticator
	 */
	public function createServiceRestful__security__timeoutAuthenticator()
	{
		$service = new Drahak\Restful\Security\Authentication\TimeoutAuthenticator('timestamp', 300);
		return $service;
	}


	/**
	 * @return Drahak\Restful\Converters\SnakeCaseConverter
	 */
	public function createServiceRestful__snakeCaseConverter()
	{
		$service = new Drahak\Restful\Converters\SnakeCaseConverter;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Validation\ValidationScope
	 */
	public function createServiceRestful__validationScope()
	{
		$service = $this->getService('restful.validationScopeFactory')->create();
		if (!$service instanceof Drahak\Restful\Validation\ValidationScope) {
			throw new Nette\UnexpectedValueException('Unable to create service \'restful.validationScope\', value returned by factory is not Drahak\Restful\Validation\ValidationScope type.');
		}
		return $service;
	}


	/**
	 * @return Drahak\Restful\Validation\ValidationScopeFactory
	 */
	public function createServiceRestful__validationScopeFactory()
	{
		$service = new Drahak\Restful\Validation\ValidationScopeFactory($this->getService('restful.validator'));
		return $service;
	}


	/**
	 * @return Drahak\Restful\Validation\Validator
	 */
	public function createServiceRestful__validator()
	{
		$service = new Drahak\Restful\Validation\Validator;
		return $service;
	}


	/**
	 * @return Drahak\Restful\Mapping\XmlMapper
	 */
	public function createServiceRestful__xmlMapper()
	{
		$service = new Drahak\Restful\Mapping\XmlMapper;
		return $service;
	}


	/**
	 * @return Nette\Application\IRouter
	 */
	public function createServiceRouting__router()
	{
		$service = Ukoly\RouterFactory::createRouter();
		if (!$service instanceof Nette\Application\IRouter) {
			throw new Nette\UnexpectedValueException('Unable to create service \'routing.router\', value returned by factory is not Nette\Application\IRouter type.');
		}
		return $service;
	}


	/**
	 * @return Nette\Security\User
	 */
	public function createServiceSecurity__user()
	{
		$service = new Nette\Security\User($this->getService('security.userStorage'));
		$this->getService('tracy.bar')->addPanel(new Nette\Bridges\SecurityTracy\UserPanel($service));
		return $service;
	}


	/**
	 * @return Nette\Security\IUserStorage
	 */
	public function createServiceSecurity__userStorage()
	{
		$service = new Nette\Http\UserStorage($this->getService('session.session'));
		return $service;
	}


	/**
	 * @return Nette\Http\Session
	 */
	public function createServiceSession__session()
	{
		$service = new Nette\Http\Session($this->getService('http.request'), $this->getService('http.response'));
		$service->setExpiration('14 days');
		return $service;
	}


	/**
	 * @return Tracy\Bar
	 */
	public function createServiceTracy__bar()
	{
		$service = Tracy\Debugger::getBar();
		if (!$service instanceof Tracy\Bar) {
			throw new Nette\UnexpectedValueException('Unable to create service \'tracy.bar\', value returned by factory is not Tracy\Bar type.');
		}
		return $service;
	}


	/**
	 * @return Tracy\BlueScreen
	 */
	public function createServiceTracy__blueScreen()
	{
		$service = Tracy\Debugger::getBlueScreen();
		if (!$service instanceof Tracy\BlueScreen) {
			throw new Nette\UnexpectedValueException('Unable to create service \'tracy.blueScreen\', value returned by factory is not Tracy\BlueScreen type.');
		}
		return $service;
	}


	/**
	 * @return Tracy\ILogger
	 */
	public function createServiceTracy__logger()
	{
		$service = Tracy\Debugger::getLogger();
		if (!$service instanceof Tracy\ILogger) {
			throw new Nette\UnexpectedValueException('Unable to create service \'tracy.logger\', value returned by factory is not Tracy\ILogger type.');
		}
		return $service;
	}


	/**
	 * @return Ukoly\Model\Translation\BlankTranslator
	 */
	public function createServiceTranslator()
	{
		$service = new Ukoly\Model\Translation\BlankTranslator;
		return $service;
	}


	public function initialize()
	{
		date_default_timezone_set('Europe/Prague');
		header('X-Frame-Options: SAMEORIGIN');
		header('X-Powered-By: Nette Framework');
		header('Content-Type: text/html; charset=utf-8');
		Nette\Reflection\AnnotationsParser::setCacheStorage($this->getByType("Nette\Caching\IStorage"));
		Nette\Reflection\AnnotationsParser::$autoRefresh = TRUE;
		$this->getService('session.session')->start();
		$this->getService('ErrorPresenter.factory')->setDefaultErrorPresenter($this->getService('application')->errorPresenter);
		$this->getService('application')->errorPresenter = $this->getService('ErrorPresenter.factory')->getErrorPresenter();
	}

}



final class Container_725ec0de55_Nette_Bridges_ApplicationLatte_ILatteFactoryImpl_latte_latteFactory implements Nette\Bridges\ApplicationLatte\ILatteFactory
{
	private $container;


	public function __construct(Container_725ec0de55 $container)
	{
		$this->container = $container;
	}


	public function create()
	{
		$service = new Latte\Engine;
		$service->setTempDirectory("E:\\Pracovn\xed\\V\x8aE DEV\\ukoly\\app/../temp/cache/latte");
		$service->setAutoRefresh(TRUE);
		$service->setContentType('html');
		Nette\Utils\Html::$xhtml = FALSE;
		return $service;
	}

}
