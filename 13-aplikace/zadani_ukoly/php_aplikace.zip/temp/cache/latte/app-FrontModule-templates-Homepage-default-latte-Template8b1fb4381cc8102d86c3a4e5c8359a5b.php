<?php
// source: E:\Pracovn�\V�E DEV\ukoly\app\FrontModule/templates/Homepage/default.latte

class Template8b1fb4381cc8102d86c3a4e5c8359a5b extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('0874001845', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb273c76ad55_content')) { function _lb273c76ad55_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>  <h1>Aplikace s API pro práci s osobami a úkoly v předmětu 4iz268</h1>

<a href="<?php echo Latte\Runtime\Filters::escapeHtml($_presenter->link(":Rest:Swagger:ui"), ENT_COMPAT) ?>">zobrazit API...</a>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start(function () {});}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIRuntime::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}