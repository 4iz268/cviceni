<?php
// source: E:\Pracovn�\V�E\fulltext-repository\app\FrontModule/templates/Publications/default.latte

class Template998bb32874956915d0d5654454538bdd extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('46d0bd9ad3', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb0db2d59e5d_content')) { function _lb0db2d59e5d_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>

<?php if (!empty($publications)) { ?>
    <table class="listTable fullWidth">
      <tr>
        <th scope="col"><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('Název'), ENT_NOQUOTES) ?></th>
        <th scope="col"><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('Typ publikace'), ENT_NOQUOTES) ?></th>
        <th scope="col"><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('Stav'), ENT_NOQUOTES) ?></th>
        <th scope="col"><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('Akce'), ENT_NOQUOTES) ?></th>
      </tr>

<?php $iterations = 0; foreach ($publications as $publication) { ?>
        <tr>
          <td><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Publications:show", array('id'=>$publication->publicationId)), ENT_COMPAT) ?>
"><?php echo Latte\Runtime\Filters::escapeHtml($publication->title, ENT_NOQUOTES) ?></a></td>
          <td><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('type:'.$publication->type), ENT_NOQUOTES) ?></td>
          <td<?php if ($_l->tmp = array_filter(array($publication->state))) echo ' class="', Latte\Runtime\Filters::escapeHtml(implode(" ", array_unique($_l->tmp)), ENT_COMPAT), '"' ?>
><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('state:'.$publication->state), ENT_NOQUOTES) ?></td>
          <td class="actions">
            <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Publications:show", array('id'=>$publication->publicationId)), ENT_COMPAT) ?>
"><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('zobrazit'), ENT_NOQUOTES) ?></a>
          </td>
        </tr>
<?php $iterations++; } ?>
    </table>
<?php } else { ?>
    <div class="info"><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('Nemáte v tomto systému evidovány žádné publikace.'), ENT_NOQUOTES) ?></div>
<?php } 
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb1cb2e09698_title')) { function _lb1cb2e09698_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>  <h1><?php echo Latte\Runtime\Filters::escapeHtml($template->translate('Přehled publikací'), ENT_NOQUOTES) ?></h1>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start(function () {});}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIRuntime::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
?>

<?php if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}