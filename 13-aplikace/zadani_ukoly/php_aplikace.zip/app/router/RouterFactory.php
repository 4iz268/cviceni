<?php

namespace Ukoly;

use Drahak\Restful\Application\IResourceRouter;
use Drahak\Restful\Application\Routes\CrudRoute;
use Nette;
use Nette\Application\Routers\RouteList;
use Nette\Application\Routers\Route;


class RouterFactory
{

	/**
	 * @return Nette\Application\IRouter
	 */
	public static function createRouter($secured=false)
	{
		$router = new RouteList;


    $restRouter=new RouteList('Rest');
    $restRouter[]=new Route('api/swagger[/<action=ui>]', ['presenter' => 'Swagger']);
    $routeFlags=IResourceRouter::GET | IResourceRouter::POST | IResourceRouter::PUT | IResourceRouter::DELETE;
    if ($secured){
      $routeFlags |= IResourceRouter::SECURED;
    }
    $restRouter[] = new CrudRoute('api/<presenter>[/<id>[/<relation>[/<relationId>]]]', [], $routeFlags);
    $restRouter[] = new Route('api', ['presenter' => 'Default', 'action' => 'default'], ($secured?Route::SECURED:0));
		$router[] =  $restRouter;

    $frontRouter = new RouteList('Front');
    $frontRouter[] = new Route('','Homepage:default');
    $frontRouter[]=new Route('<presenter>[/<action=default>[/<id>]]', [], ($secured?Route::SECURED:0));
    $router[] = $frontRouter;

		return $router;
	}

}
