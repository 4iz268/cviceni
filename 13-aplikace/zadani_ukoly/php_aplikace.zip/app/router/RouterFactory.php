<?php

namespace Ukoly\Router;

use Nette;
use Nette\Application\Routers\RouteList;

/**
 * Class RouterFactory
 * @package Ukoly\Router
 * @author Stanislav Vojíř
 */
class RouterFactory{
  use Nette\StaticClass;

  /**
   * @return Nette\Application\IRouter
   */
  public static function createRouter(Nette\Http\IRequest $request){
    $basePath=$request->getUrl()->basePath;
    $router=new RouteList();
    $router[]=\Ukoly\RestModule\Router\RouterFactory::createRouter($basePath);
    $router[]=\Ukoly\FrontModule\Router\RouterFactory::createRouter();
    return $router;
  }
}
