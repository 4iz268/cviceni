<?php

namespace Ukoly\RestModule\Presenters;
use Nette\Application\BadRequestException;
use Nette\Application\Responses\TextResponse;
use Nette\Utils\Json;
use Ukoly\Model\Entities\Person;
use Ukoly\Model\Facades\PersonsFacade;

/**
 * Class PersonsPresenter - presenter pro práci s datovými zdroji
 * @package Ukoly\RestModule\Presenters
 */
class PersonsPresenter extends BaseResourcePresenter{

  /** @var  PersonsFacade $personsFacade */
  private $personsFacade;

  /**
   * @SWG\Post(
   *   tags={"Persons"},
   *   path="/persons",
   *   summary="Create new person",
   *   consumes={"application/json"},
   *   produces={"application/json"},
   *   @SWG\Parameter(
   *     description="New person",
   *     name="body",
   *     required=true,
   *     @SWG\Schema(ref="#/definitions/NewPersonInput"),
   *     in="body"
   *   ),
   *   @SWG\Response(
   *     response=201,
   *     description="Person created",
   *     @SWG\Schema(
   *       ref="#/definitions/PersonResponse"
   *     )
   *   )
   * )
   * @throws \InvalidArgumentException
   */
  public function actionCreate() {
    /** @var array $inputData */
    $inputData=Json::decode($this->getHttpRequest()->getRawBody(),Json::FORCE_ARRAY);
    $person=new Person();
    $person->name=$inputData['name'];
    $person->email=$inputData['email'];
    $person->street=(!empty($inputData['street'])?$inputData['street']:'');
    $person->city=(!empty($inputData['city'])?$inputData['city']:'');
    $person->phone=(!empty($inputData['phone'])?$inputData['phone']:'');
    $person->zip=(!empty($inputData['zip'])?$inputData['zip']:'');
    $this->personsFacade->savePerson($person);
    $this->sendJson($person->getDataArr());
  }

  /**
   * @SWG\Put(
   *   tags={"Persons"},
   *   path="/persons/{id}",
   *   summary="Update person details",
   *   consumes={"application/json"},
   *   produces={"application/json"},
   *   security={{"apiKey":{}},{"apiKeyHeader":{}}},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Person ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Parameter(
   *     description="Person properties",
   *     name="body",
   *     required=true,
   *     @SWG\Schema(ref="#/definitions/NewPersonInput"),
   *     in="body"
   *   ),
   *   @SWG\Response(
   *     response=200,
   *     description="Person updated",
   *     @SWG\Schema(
   *       ref="#/definitions/PersonResponse"
   *     )
   *   )
   * )
   * @throws \InvalidArgumentException
   */
  public function actionUpdate($id) {
    /** @var array $inputData */
    $inputData=Json::decode($this->getHttpRequest()->getRawBody(),Json::FORCE_ARRAY);
    $person=$this->personsFacade->findPerson($id);
    $person->name=$inputData['name'];
    $person->email=$inputData['email'];
    $person->street=(!empty($inputData['street'])?$inputData['street']:'');
    $person->city=(!empty($inputData['city'])?$inputData['city']:'');
    $person->phone=(!empty($inputData['phone'])?$inputData['phone']:'');
    $person->zip=(!empty($inputData['zip'])?$inputData['zip']:'');
    $this->personsFacade->savePerson($person);
    $this->sendJson($person->getDataArr());
  }

  #region actionRead/actionList
  /**
   * @param int|null $id=null
   * @throws BadRequestException
   * @SWG\Get(
   *   tags={"Persons"},
   *   path="/persons/{id}",
   *   summary="Get person details",
   *   produces={"application/json"},
   *   security={{"apiKey":{}},{"apiKeyHeader":{}}},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Person ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Response(
   *     response=200,
   *     description="Person details",
   *     @SWG\Schema(
   *       ref="#/definitions/PersonResponse"
   *     )
   *   ),
   *   @SWG\Response(response=404, description="Requested person was not found.")
   * )
   */
  public function actionRead($id=null) {
    if ($id==null){
      $this->forward('list');return;
    }
    $this->sendJson($this->personsFacade->findPerson($id)->getDataArr());
  }

  /**
   * Akce vracející seznam datových zdrojů pro aktuálního uživatele
   * @SWG\Get(
   *   tags={"Persons"},
   *   path="/persons",
   *   summary="Get list of persons",
   *   produces={"application/json"},
   *   @SWG\Response(
   *     response="200",
   *     description="List of persons",
   *     @SWG\Schema(
   *       type="array",
   *       @SWG\Items(
   *         ref="#/definitions/PersonResponse"
   *       )
   *     )
   *   )
   * )
   */
  public function actionList() {
    $persons=$this->personsFacade->findPersons();
    $result=[];
    if (!empty($persons)){
      foreach ($persons as $person){
        $result[]=$person->getDataArr(true);
      }
    }
    $this->sendJson($result);
  }
  #endregion actionRead/actionList

  /**
   * @SWG\Delete(
   *   tags={"Persons"},
   *   path="/persons/{id}",
   *   summary="Delete person",
   *   consumes={"application/json"},
   *   produces={"application/json"},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Person ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Response(
   *     response=200,
   *     description="Person deleted"
   *   )
   * )
   * @throws \InvalidArgumentException
   */
  public function actionDelete($id) {
    $person=$this->personsFacade->findPerson($id);
    $this->personsFacade->deletePerson($person);
    $this->sendJson(['status'=>'ok']);
  }

  /**
   * Akce vracející seznam datových zdrojů pro aktuálního uživatele
   * @SWG\Get(
   *   tags={"Persons","Tasks"},
   *   path="/persons/{id}/tasks",
   *   summary="Get list of tasks by person",
   *   produces={"application/json"},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Person ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Response(
   *     response="200",
   *     description="List of tasks",
   *     @SWG\Schema(
   *       type="array",
   *       @SWG\Items(
   *         ref="#/definitions/TaskBasicResponse"
   *       )
   *     )
   *   )
   * )
   */
  public function actionReadTasks($id) {
    $person=$this->personsFacade->findPerson($id);
    $result=[];
    if (!empty($person->tasks)){
      foreach($person->tasks as $task){
        $result[]=$task->getDataArr(true);
      }
    }
    $this->sendJson($result);
  }

  public function actionOptions(){
    $this->sendResponse(new TextResponse(''));
  }

  #region injections
  /**
   * @param PersonsFacade $personsFacade
   */
  public function injectPersonsFacade(PersonsFacade $personsFacade) {
    $this->personsFacade=$personsFacade;
  }
  #endregion injections
}

/**
 * @SWG\Definition(
 *   definition="PersonResponse",
 *   title="PersonInfo",
 *   required={"id","name","email"},
 *   @SWG\Property(property="id",type="integer",description="Unique ID of the person"),
 *   @SWG\Property(property="name",type="string",description="Name of the person"),
 *   @SWG\Property(property="email",type="string",description="Email of the person"),
 * )
 *
 * @SWG\Definition(
 *   definition="TaskBasicResponse",
 *   title="TaskInfo",
 *   required={"id","title","priority"},
 *   @SWG\Property(property="id",type="integer",description="Unique ID of the task"),
 *   @SWG\Property(property="priority",type="string",description="Priority level",enum={"high","normal","low"}),
 *   @SWG\Property(property="title",type="string",description="Title of the task"),
 *   @SWG\Property(property="person",type="integer",description="ID of the person"),
 * )
 *
 *  @SWG\Definition(
 *   definition="NewPersonInput",
 *   title="New person",
 *   required={"name","title","person"},
 *   @SWG\Property(property="name",type="string",description="Name of the person"),
 *   @SWG\Property(property="email",type="string",description="Email of the person"),
 * )
 *
 */