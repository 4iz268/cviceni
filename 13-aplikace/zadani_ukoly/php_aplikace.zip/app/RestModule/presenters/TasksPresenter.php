<?php

namespace Ukoly\RestModule\Presenters;
use Nette\Application\BadRequestException;
use Nette\Application\Responses\TextResponse;
use Nette\Utils\Json;
use Ukoly\Model\Entities\Task;
use Ukoly\Model\Facades\PersonsFacade;

/**
 * Class TaskPresenter - presenter pro práci s datovými zdroji
 * @package Ukoly\RestModule\Presenters
 */
class TasksPresenter extends BaseResourcePresenter{

  /** @var  PersonsFacade $personsFacade */
  private $personsFacade;

  /**
   * @SWG\Post(
   *   tags={"Tasks"},
   *   path="/tasks",
   *   summary="Create new task",
   *   consumes={"application/json"},
   *   produces={"application/json"},
   *   @SWG\Parameter(
   *     description="New task",
   *     name="body",
   *     required=true,
   *     @SWG\Schema(ref="#/definitions/NewTaskInput"),
   *     in="body"
   *   ),
   *   @SWG\Response(
   *     response=201,
   *     description="Task created",
   *     @SWG\Schema(
   *       ref="#/definitions/TaskResponse"
   *     )
   *   )
   * )
   * @throws \InvalidArgumentException
   */
  public function actionCreate() {
    /** @var array $inputData */
    $inputData=Json::decode($this->getHttpRequest()->getRawBody(),Json::FORCE_ARRAY);
    $task=new Task();
    $task->title=$inputData['title'];
    $task->description=(!empty($inputData['description'])?$inputData['description']:'');
    $task->priority=(!empty($inputData['priority'])?$inputData['priority']:Task::PRIORITY_NORMAL);
    $task->person=$this->personsFacade->findPerson($inputData['person']);
    $this->personsFacade->saveTask($task);
    $this->sendJson($task->getDataArr());
  }

  /**
   * @SWG\Put(
   *   tags={"Tasks"},
   *   path="/tasks/{id}",
   *   summary="Update person details",
   *   consumes={"application/json"},
   *   produces={"application/json"},
   *   security={{"apiKey":{}},{"apiKeyHeader":{}}},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Task ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Parameter(
   *     description="Task properties",
   *     name="body",
   *     required=true,
   *     @SWG\Schema(ref="#/definitions/NewTaskInput"),
   *     in="body"
   *   ),
   *   @SWG\Response(
   *     response=200,
   *     description="Task updated",
   *     @SWG\Schema(
   *       ref="#/definitions/PersonResponse"
   *     )
   *   )
   * )
   * @throws \InvalidArgumentException
   */
  public function actionUpdate($id) {
    /** @var array $inputData */
    $inputData=Json::decode($this->getHttpRequest()->getRawBody(),Json::FORCE_ARRAY);
    $task=$this->personsFacade->findTask($id);
    $task->title=$inputData['title'];
    $task->description=(!empty($inputData['description'])?$inputData['description']:'');
    $task->priority=(!empty($inputData['priority'])?$inputData['priority']:Task::PRIORITY_NORMAL);
    $task->person=$this->personsFacade->findPerson($inputData['person']);
    $this->personsFacade->saveTask($task);
    $this->sendJson($task->getDataArr());
  }

  #region actionRead/actionList
  /**
   * @param int|null $id=null
   * @throws BadRequestException
   * @SWG\Get(
   *   tags={"Tasks"},
   *   path="/tasks/{id}",
   *   summary="Get task details",
   *   produces={"application/json"},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Person ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Response(
   *     response=200,
   *     description="Task details",
   *     @SWG\Schema(
   *       ref="#/definitions/TaskResponse"
   *     )
   *   ),
   *   @SWG\Response(response=404, description="Requested task was not found.")
   * )
   */
  public function actionRead($id=null) {
    if ($id==null){
      $this->forward('list');return;
    }
    $this->sendJson($this->personsFacade->findTask($id)->getDataArr());
  }

  /**
   * Akce vracející seznam datových zdrojů pro aktuálního uživatele
   * @SWG\Get(
   *   tags={"Tasks"},
   *   path="/tasks",
   *   summary="Get list of tasks",
   *   produces={"application/json"},
   *   @SWG\Response(
   *     response="200",
   *     description="List of tasks",
   *     @SWG\Schema(
   *       type="array",
   *       @SWG\Items(
   *         ref="#/definitions/TaskBasicResponse"
   *       )
   *     )
   *   )
   * )
   */
  public function actionList() {
    $tasks=$this->personsFacade->findTasks();
    $result=[];
    if (!empty($tasks)){
      foreach ($tasks as $task){
        $result[]=$task->getDataArr(true);
      }
    }
    $this->sendJson($result);
  }
  #endregion actionRead/actionList

  /**
   * @SWG\Delete(
   *   tags={"Tasks"},
   *   path="/tasks/{id}",
   *   summary="Delete task",
   *   consumes={"application/json"},
   *   produces={"application/json"},
   *   @SWG\Parameter(
   *     name="id",
   *     description="Task ID",
   *     required=true,
   *     type="integer",
   *     in="path"
   *   ),
   *   @SWG\Response(
   *     response=200,
   *     description="Person deleted"
   *   )
   * )
   * @throws \InvalidArgumentException
   */
  public function actionDelete($id) {
    $task=$this->personsFacade->findTask($id);
    $this->personsFacade->deleteTask($task);
    $this->sendJson(['status'=>'ok']);
  }


  public function actionOptions(){
    $this->sendResponse(new TextResponse(''));
  }


  #region injections
  /**
   * @param PersonsFacade $personsFacade
   */
  public function injectPersonsFacade(PersonsFacade $personsFacade) {
    $this->personsFacade=$personsFacade;
  }
  #endregion injections
}

/**
 *
 * @SWG\Definition(
 *   definition="TaskResponse",
 *   title="TaskInfo",
 *   required={"id","title","priority"},
 *   @SWG\Property(property="id",type="integer",description="Unique ID of the task"),
 *   @SWG\Property(property="priority",type="string",description="Priority level",enum={"high","normal","low"}),
 *   @SWG\Property(property="title",type="string",description="Title of the task"),
 *   @SWG\Property(property="description",type="string",description="Description of the task"),
 *   @SWG\Property(property="person",type="integer",description="ID of the person"),
 * )
 *
 * *  @SWG\Definition(
 *   definition="NewTaskInput",
 *   title="New person",
 *   required={"name","title","person"},
 *   @SWG\Property(property="priority",type="string",description="Priority level",enum={"high","normal","low"}),
 *   @SWG\Property(property="title",type="string",description="Title of the task"),
 *   @SWG\Property(property="description",type="string",description="Description of the task"),
 *   @SWG\Property(property="person",type="integer",description="ID of the person"),
 * )
 */