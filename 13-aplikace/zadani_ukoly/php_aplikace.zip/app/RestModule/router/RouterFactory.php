<?php

namespace Ukoly\RestModule\Router;

use Nette;
use Nette\Application\Routers\Route;
use Nette\Application\Routers\RouteList;
use Contributte\ApiRouter\ApiRoute;

/**
 * Class RouterFactory
 * @package Kalendar\RestModule\Router
 * @author Stanislav Vojíř
 */
class RouterFactory{
  use Nette\StaticClass;


  /**
   * @return Nette\Application\IRouter
   */
  public static function createRouter($basePath){
    $router=new RouteList('Rest');
    $basePath=trim($basePath,'/');

    $router[] = new ApiRoute('/'.$basePath.'/api/persons/<id>/tasks', 'Persons', [
      'parameters' => [
        'id' => ['requirement' => '\d+'],
      ],
      'methods'=>['GET'=>'readTasks'],
      'priority' => 1
    ]);

    $router[] = new ApiRoute('/'.$basePath.'/api/persons[/<id>]', 'Persons', [
      'parameters' => [
        'id' => ['requirement' => '\d+'],
      ],
      'methods'=>['GET','POST','PUT','DELETE','OPTIONS'=>'options'],
      'priority' => 1
    ]);

    $router[] = new ApiRoute('/'.$basePath.'/api/tasks[/<id>]', 'Tasks', [
      'parameters' => [
        'id' => ['requirement' => '\d+'],
      ],
      'methods'=>['GET','POST','PUT','DELETE','OPTIONS'=>'options'],
      'priority' => 1
    ]);
    $router[]=new Route('api/<presenter=Swagger>/<action=ui>');
    return $router;
  }
}
