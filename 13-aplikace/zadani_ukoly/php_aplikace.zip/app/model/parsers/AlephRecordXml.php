<?php

namespace Ukoly\Model\Parsers;

/**
 * Class AlephRecordXml - třída pro parsování jednoho záznamu z AlephXml
 * @package Ukoly\Model\Parsers
 * @author Stanislav Vojíř
 */
class AlephRecordXml{
  /** @var  \SimpleXMLElement $xml */
  private $xml;

  public function __construct(\SimpleXMLElement $xml){

  }

  /**
   * Funkce vracející název publikace
   * @return string
   */
  public function getTitle(){
    //TODO
  }



  /**
   * Funkce pro načtení názvu publikace
   * @param string $language
   * @return string
   */
  public function getTitleTranslation($language=''){
    //TODO
  }

}