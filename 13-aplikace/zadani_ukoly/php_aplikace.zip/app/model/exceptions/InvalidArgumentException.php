<?php

namespace Ukoly\Model\Exceptions;
use LeanMapper\Exception\Exception;

class InvalidArgumentException extends Exception{

}