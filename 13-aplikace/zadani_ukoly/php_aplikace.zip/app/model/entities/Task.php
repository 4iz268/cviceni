<?php

namespace Ukoly\Model\Entities;


use LeanMapper\Entity;

/**
 * Class Task
 * @package Ukoly\Model\Entities
 * @author Stanislav Vojíř
 * @property int|null $taskId
 * @property string $title
 * @property string $description
 * @property string $priority m:Enum(self::PRIORITY_*)
 * @property Person $person m:hasOne
 */
class Task extends Entity{
  const PRIORITY_HIGH='high';
  const PRIORITY_NORMAL='normal';
  const PRIORITY_LOW='low';


  public function getDataArr($onlyBasicInfo=false){
    $result=[
      'id'=>$this->taskId,
      'title'=>$this->title,
      'priority'=>$this->priority
    ];
    if (!$onlyBasicInfo){
      $result['description']=@$this->description;
      $result['person']=@$this->person->personId;
    }
    return $result;
  }
}