<?php
namespace Ukoly\Model\Translation;


use Nette\Localization\Translator;

/**
 * Interface UkolyTranslator
 * @package Ukoly\Model\Translation
 * @author Stanislav Vojíř
 */
interface IUkolyTranslator extends Translator{

  /**
   * Funkce vracející aktuálně nastavený jazyk
   * @return string
   */
  public function getLang();

}