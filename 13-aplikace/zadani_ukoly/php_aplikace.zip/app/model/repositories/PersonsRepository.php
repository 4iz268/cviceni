<?php

namespace Ukoly\Model\Repositories;


class PersonsRepository extends BaseRepository{

}