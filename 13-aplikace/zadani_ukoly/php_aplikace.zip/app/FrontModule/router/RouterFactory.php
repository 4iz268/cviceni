<?php

namespace Ukoly\FrontModule\Router;

use Nette;
use Nette\Application\Routers\Route;
use Nette\Application\Routers\RouteList;

/**
 * Class RouterFactory
 * @package Ukoly\FrontModule\Router
 * @author Stanislav Vojíř
 */
class RouterFactory{
  use Nette\StaticClass;

  /**
   * @return Nette\Application\IRouter
   */
  public static function createRouter(){
    $router=new RouteList('Front');
    $router[] = new Route('','Homepage:default');
    $router[]=new Route('<presenter>[/<action=default>[/<id>]]', []);
    return $router;
  }
}
