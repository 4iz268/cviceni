<?php

namespace Ukoly\FrontModule\Presenters;

use Nette;


class HomepagePresenter extends BasePresenter{



}
